Registro del usuario API REST

Resquest
{
  "name": "string",
  "email": "string",
  "password": "string",
  "address": "string",
  "phone_number": "string",
  "city": "string",
  "country": "string"
}

Response
{
  "id": "integer",
  "name": "string",
  "email": "string",
  "address": "string",
  "phone_number": "string",
  "city": "string",
  "country": "string"
}

Login
Request
{
  "email": "string",
  "password": "string"
}
Response
{
  "token": "string",
  "user": {
    "id": "integer",
    "name": "string",
    "email": "string",
    "address": "string",
    "phone_number": "string",
    "city": "string",
    "country": "string"
  }
}

Post 
Productos	
Request
{
  "name": "string",
  "description": "string",
  "value": "number",
  "photo": "string"
}
Response
{
  "id": "integer",
  "name": "string",
  "description": "string",
  "value": "number",
  "photo": "string",
  "user_id": "integer"
}

1.	Obtener detalles de un producto:
GET /products/{id}
•	Response:
{
  "id": "integer",
  "name": "string",
  "description": "string",
  "value": "number",
  "photo": "string",
  "user_id": "integer"
}

2.	Actualizar un producto:
PUT /products/{id}
•	Request:

{
  "name": "string",
  "description": "string",
  "value": "number",
  "photo": "string"
}

•	Response:

{
  "id": "integer",
  "name": "string",
  "description": "string",
  "value": "number",
  "photo": "string",
  "user_id": "integer"
}

3.	Eliminar un producto:
DELETE /products/{id}
4.	Obtener todos los productos:
GET /products
•	Response:

{
  "products": [
    {
      "id": "integer",
      "name": "string",
      "description": "string",
      "value": "number",
      "photo": "string",
      "user_id": "integer"
    },
    ...
  ]
5.	Obtener productos por criterios de búsqueda:
GET /products?search=keyword
•	Response:
{
  "products": [
    {
      "id": "integer",
      "name": "string",
      "description": "string",
      "value": "number",
      "photo": "string",
      "user_id": "integer"
    },
    ...
  ]
}
